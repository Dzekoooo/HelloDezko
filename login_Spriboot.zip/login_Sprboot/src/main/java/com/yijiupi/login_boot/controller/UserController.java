package com.yijiupi.login_boot.controller;


import com.yijiupi.login_boot.pojo.UserVO;
import com.yijiupi.login_boot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpSession;


@Controller
@RequestMapping("/user")

/**
*@Author: ZhangZhe
*@Description  Controller层
*@Date: 13:49 2017/12/7
*/

public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/login")
    public ModelAndView login(@RequestParam(value = "name", required = false) String loginName,
                              @RequestParam(value = "pWord", required = false) String password,
                              HttpSession session, ModelAndView mv){
        if (null == loginName || password == null){
            mv.setViewName("login");
        } else {
            //判断是否可以登录
            userService.login(loginName, password);
            UserVO userVO = userService.checkName(loginName, password);
            if (null != userVO){
                session.setAttribute("userVO", userVO);
                mv.setViewName("success");
            } else {
                mv.setViewName("loginForm");
            }
        }
        return mv;
    }

    @RequestMapping(value = "/register")
    public ModelAndView register(@RequestParam(value = "name", required = false)  String userName,
                                 @RequestParam(value = "userPass", required = false) String password,
                         ModelAndView mv) throws Exception {
        if (null == userName || password == null){
            mv.setViewName("register");
        } else {
            //判断用户名是否存在
            UserVO userVO = userService.checkName(userName, password);
            if (null != userVO){
                mv.addObject("message", "用户名已存在，请直接登录");
                mv.setViewName("login");
            }else {
                Boolean registerResult = userService.register(userName, password);
                if (true == registerResult){
                    mv.setViewName("login");
                } else {
                    mv.addObject("message", "注册失败,请重新注册");
                    mv.setViewName("registerForm");
                }
            }
        }
        return mv;
    }
}
